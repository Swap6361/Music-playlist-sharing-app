import { useState, useCallback } from 'react';
import { Playlist, Song } from '../types';
import { useLocalStorage } from './useLocalStorage';
import { mockPlaylists } from '../data/mockData';

export function usePlaylist() {
  const [playlists, setPlaylists] = useLocalStorage<Playlist[]>('playlists', mockPlaylists);
  const [currentPlaylist, setCurrentPlaylist] = useState<Playlist | null>(null);

  const createPlaylist = useCallback((name: string, description: string) => {
    const newPlaylist: Playlist = {
      id: `playlist_${Date.now()}`,
      name,
      description,
      coverUrl: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400',
      songs: [],
      createdBy: 'user1',
      createdAt: new Date(),
      isPublic: true,
      shareCode: Math.random().toString(36).substring(2, 8).toUpperCase(),
      collaborators: []
    };
    
    setPlaylists(prev => [...prev, newPlaylist]);
    return newPlaylist;
  }, [setPlaylists]);

  const addSongToPlaylist = useCallback((playlistId: string, song: Song) => {
    setPlaylists(prev => prev.map(playlist => 
      playlist.id === playlistId 
        ? { ...playlist, songs: [...playlist.songs, song] }
        : playlist
    ));
  }, [setPlaylists]);

  const removeSongFromPlaylist = useCallback((playlistId: string, songId: string) => {
    setPlaylists(prev => prev.map(playlist => 
      playlist.id === playlistId 
        ? { ...playlist, songs: playlist.songs.filter(song => song.id !== songId) }
        : playlist
    ));
  }, [setPlaylists]);

  const deletePlaylist = useCallback((playlistId: string) => {
    setPlaylists(prev => prev.filter(playlist => playlist.id !== playlistId));
  }, [setPlaylists]);

  const getPlaylistByShareCode = useCallback((shareCode: string) => {
    return playlists.find(playlist => playlist.shareCode === shareCode);
  }, [playlists]);

  return {
    playlists,
    currentPlaylist,
    setCurrentPlaylist,
    createPlaylist,
    addSongToPlaylist,
    removeSongFromPlaylist,
    deletePlaylist,
    getPlaylistByShareCode
  };
}