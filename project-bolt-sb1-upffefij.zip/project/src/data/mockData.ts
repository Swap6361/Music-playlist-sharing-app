import { Song, Playlist, User } from '../types';

export const mockSongs: Song[] = [
  {
    id: '1',
    title: 'Blinding Lights',
    artist: 'The Weeknd',
    album: 'After Hours',
    duration: 200,
    coverUrl: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop'
  },
  {
    id: '2',
    title: 'Watermelon Sugar',
    artist: 'Harry Styles',
    album: 'Fine Line',
    duration: 174,
    coverUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop'
  },
  {
    id: '3',
    title: 'Good 4 U',
    artist: 'Olivia Rodrigo',
    album: 'SOUR',
    duration: 178,
    coverUrl: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop Rock'
  },
  {
    id: '4',
    title: 'Levitating',
    artist: 'Dua Lipa',
    album: 'Future Nostalgia',
    duration: 203,
    coverUrl: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Dance Pop'
  },
  {
    id: '5',
    title: 'Stay',
    artist: 'The Kid LAROI & Justin Bieber',
    album: 'F*CK LOVE 3: OVER YOU',
    duration: 141,
    coverUrl: 'https://images.pexels.com/photos/1337386/pexels-photo-1337386.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop Rap'
  },
  {
    id: '6',
    title: 'Anti-Hero',
    artist: 'Taylor Swift',
    album: 'Midnights',
    duration: 200,
    coverUrl: 'https://images.pexels.com/photos/1699159/pexels-photo-1699159.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop'
  },
  {
    id: '7',
    title: 'As It Was',
    artist: 'Harry Styles',
    album: "Harry's House",
    duration: 167,
    coverUrl: 'https://images.pexels.com/photos/1164674/pexels-photo-1164674.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Pop Rock'
  },
  {
    id: '8',
    title: 'Heat Waves',
    artist: 'Glass Animals',
    album: 'Dreamland',
    duration: 238,
    coverUrl: 'https://images.pexels.com/photos/1370545/pexels-photo-1370545.jpeg?auto=compress&cs=tinysrgb&w=300',
    genre: 'Indie Pop'
  }
];

export const mockUser: User = {
  id: 'user1',
  name: 'Alex Johnson',
  email: 'alex@example.com',
  avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
  playlists: ['playlist1', 'playlist2']
};

export const mockPlaylists: Playlist[] = [
  {
    id: 'playlist1',
    name: 'Summer Vibes 2024',
    description: 'The perfect soundtrack for your summer adventures',
    coverUrl: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400',
    songs: [mockSongs[0], mockSongs[1], mockSongs[3]],
    createdBy: 'user1',
    createdAt: new Date('2024-01-15'),
    isPublic: true,
    shareCode: 'SUM24VIB',
    collaborators: []
  },
  {
    id: 'playlist2',
    name: 'Chill Study Session',
    description: 'Focus music for productivity',
    coverUrl: 'https://images.pexels.com/photos/1834406/pexels-photo-1834406.jpeg?auto=compress&cs=tinysrgb&w=400',
    songs: [mockSongs[7], mockSongs[2]],
    createdBy: 'user1',
    createdAt: new Date('2024-02-01'),
    isPublic: false,
    collaborators: ['user2']
  }
];