import React from 'react';
import { Play, Plus, Heart } from 'lucide-react';
import { Song } from '../types';

interface SongCardProps {
  song: Song;
  onPlay: (song: Song) => void;
  onAddToPlaylist: (song: Song) => void;
  showAddButton?: boolean;
}

export function SongCard({ song, onPlay, onAddToPlaylist, showAddButton = true }: SongCardProps) {
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="group bg-gray-800/50 backdrop-blur-sm rounded-xl p-4 border border-gray-700/50 hover:border-purple-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10">
      <div className="flex items-center space-x-4">
        <div className="relative">
          <img
            src={song.coverUrl}
            alt={`${song.title} cover`}
            className="w-16 h-16 rounded-lg object-cover"
          />
          <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <button
              onClick={() => onPlay(song)}
              className="p-2 bg-purple-600 hover:bg-purple-700 rounded-full transition-colors"
            >
              <Play className="h-4 w-4 text-white fill-current" />
            </button>
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <h3 className="text-white font-medium truncate group-hover:text-purple-400 transition-colors">
            {song.title}
          </h3>
          <p className="text-gray-400 text-sm truncate">{song.artist}</p>
          <div className="flex items-center space-x-2 mt-1">
            <span className="text-xs text-gray-500">{song.album}</span>
            <span className="text-xs text-gray-500">•</span>
            <span className="text-xs text-gray-500">{formatDuration(song.duration)}</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button className="p-2 hover:bg-gray-700 rounded-full transition-colors opacity-0 group-hover:opacity-100">
            <Heart className="h-4 w-4 text-gray-400 hover:text-red-400" />
          </button>
          {showAddButton && (
            <button
              onClick={() => onAddToPlaylist(song)}
              className="p-2 bg-purple-600/20 hover:bg-purple-600 text-purple-400 hover:text-white rounded-full transition-all opacity-0 group-hover:opacity-100"
            >
              <Plus className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}