import React, { useState } from 'react';
import { X, Copy, Share2, Link, Check } from 'lucide-react';
import { Playlist } from '../types';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  playlist: Playlist | null;
}

export function ShareModal({ isOpen, onClose, playlist }: ShareModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !playlist) return null;

  const shareUrl = `${window.location.origin}/shared/${playlist.shareCode}`;

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl p-6 w-full max-w-md border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg">
              <Share2 className="h-5 w-5 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-white">Share Playlist</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-400" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
            <img
              src={playlist.coverUrl}
              alt={playlist.name}
              className="w-12 h-12 rounded-lg object-cover"
            />
            <div>
              <h3 className="text-white font-medium">{playlist.name}</h3>
              <p className="text-gray-400 text-sm">{playlist.songs.length} songs</p>
            </div>
          </div>

          <div className="space-y-3">
            <label className="block text-sm font-medium text-gray-300">Share Link</label>
            <div className="flex items-center space-x-2">
              <div className="flex-1 flex items-center space-x-2 px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg">
                <Link className="h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  value={shareUrl}
                  readOnly
                  className="flex-1 bg-transparent text-white text-sm focus:outline-none"
                />
              </div>
              <button
                onClick={copyToClipboard}
                className="px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors flex items-center space-x-1"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4" />
                    <span className="text-sm">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    <span className="text-sm">Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="p-3 bg-blue-900/20 border border-blue-700/50 rounded-lg">
            <div className="flex items-start space-x-2">
              <div className="p-1 bg-blue-600 rounded-full">
                <Share2 className="h-3 w-3 text-white" />
              </div>
              <div>
                <p className="text-blue-400 text-sm font-medium">Share Code</p>
                <p className="text-white font-mono text-lg">{playlist.shareCode}</p>
                <p className="text-blue-300 text-xs mt-1">
                  Anyone with this code can access your playlist
                </p>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors"
        >
          Done
        </button>
      </div>
    </div>
  );
}