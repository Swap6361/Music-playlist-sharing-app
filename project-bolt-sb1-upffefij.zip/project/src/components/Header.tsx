import React from 'react';
import { Music, User, Search } from 'lucide-react';
import { mockUser } from '../data/mockData';

interface HeaderProps {
  currentView: string;
  onViewChange: (view: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export function Header({ currentView, onViewChange, searchQuery, onSearchChange }: HeaderProps) {
  return (
    <header className="bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg">
                <Music className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                PlaylistShare
              </h1>
            </div>
            
            <nav className="flex space-x-6">
              <button
                onClick={() => onViewChange('dashboard')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentView === 'dashboard'
                    ? 'bg-purple-600/20 text-purple-400'
                    : 'text-gray-300 hover:text-white hover:bg-gray-800'
                }`}
              >
                My Playlists
              </button>
              <button
                onClick={() => onViewChange('browse')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentView === 'browse'
                    ? 'bg-purple-600/20 text-purple-400'
                    : 'text-gray-300 hover:text-white hover:bg-gray-800'
                }`}
              >
                Browse Songs
              </button>
              <button
                onClick={() => onViewChange('shared')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentView === 'shared'
                    ? 'bg-purple-600/20 text-purple-400'
                    : 'text-gray-300 hover:text-white hover:bg-gray-800'
                }`}
              >
                Shared
              </button>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search songs..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent w-64"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <img
                src={mockUser.avatar}
                alt={mockUser.name}
                className="h-8 w-8 rounded-full"
              />
              <div className="text-sm">
                <p className="text-white font-medium">{mockUser.name}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}