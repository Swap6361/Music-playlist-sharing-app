import React from 'react';
import { Play, Share2, MoreHorizontal, Music2 } from 'lucide-react';
import { Playlist } from '../types';

interface PlaylistCardProps {
  playlist: Playlist;
  onPlay: (playlist: Playlist) => void;
  onShare: (playlist: Playlist) => void;
  onEdit: (playlist: Playlist) => void;
}

export function PlaylistCard({ playlist, onPlay, onShare, onEdit }: PlaylistCardProps) {
  const formatDuration = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
  };

  const totalDuration = playlist.songs.reduce((acc, song) => acc + song.duration, 0);

  return (
    <div className="group bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 hover:border-purple-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10">
      <div className="relative mb-4">
        <img
          src={playlist.coverUrl}
          alt={playlist.name}
          className="w-full h-48 object-cover rounded-lg"
        />
        <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <button
            onClick={() => onPlay(playlist)}
            className="p-3 bg-purple-600 hover:bg-purple-700 rounded-full transition-colors"
          >
            <Play className="h-6 w-6 text-white fill-current" />
          </button>
        </div>
      </div>
      
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-white font-semibold text-lg group-hover:text-purple-400 transition-colors">
              {playlist.name}
            </h3>
            <p className="text-gray-400 text-sm mt-1">{playlist.description}</p>
          </div>
          <button
            onClick={() => onEdit(playlist)}
            className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-700 rounded transition-all"
          >
            <MoreHorizontal className="h-4 w-4 text-gray-400" />
          </button>
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Music2 className="h-4 w-4" />
              <span>{playlist.songs.length} songs</span>
            </div>
            <span>{formatDuration(totalDuration)}</span>
          </div>
          
          <button
            onClick={() => onShare(playlist)}
            className="flex items-center space-x-1 text-purple-400 hover:text-purple-300 transition-colors"
          >
            <Share2 className="h-4 w-4" />
            <span>Share</span>
          </button>
        </div>
        
        {playlist.isPublic && (
          <div className="flex items-center justify-between pt-2 border-t border-gray-700">
            <span className="text-xs text-green-400">Public</span>
            <span className="text-xs text-gray-500 font-mono">#{playlist.shareCode}</span>
          </div>
        )}
      </div>
    </div>
  );
}