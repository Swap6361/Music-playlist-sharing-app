import React from 'react';
import { X, Plus, Music } from 'lucide-react';
import { Song, Playlist } from '../types';

interface AddToPlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  song: Song | null;
  playlists: Playlist[];
  onAddToPlaylist: (playlistId: string, song: Song) => void;
}

export function AddToPlaylistModal({ 
  isOpen, 
  onClose, 
  song, 
  playlists, 
  onAddToPlaylist 
}: AddToPlaylistModalProps) {
  if (!isOpen || !song) return null;

  const handleAddToPlaylist = (playlistId: string) => {
    onAddToPlaylist(playlistId, song);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl p-6 w-full max-w-md border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg">
              <Plus className="h-5 w-5 text-white" />
            </div>
            <h2 className="text-xl font-semibold text-white">Add to Playlist</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X className="h-5 w-5 text-gray-400" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
            <img
              src={song.coverUrl}
              alt={song.title}
              className="w-12 h-12 rounded-lg object-cover"
            />
            <div>
              <h3 className="text-white font-medium">{song.title}</h3>
              <p className="text-gray-400 text-sm">{song.artist}</p>
            </div>
          </div>

          <div className="space-y-2 max-h-64 overflow-y-auto">
            {playlists.length === 0 ? (
              <div className="text-center py-8">
                <Music className="h-12 w-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-400">No playlists yet</p>
                <p className="text-gray-500 text-sm">Create your first playlist to get started</p>
              </div>
            ) : (
              playlists.map((playlist) => {
                const songExists = playlist.songs.some(s => s.id === song.id);
                return (
                  <button
                    key={playlist.id}
                    onClick={() => !songExists && handleAddToPlaylist(playlist.id)}
                    disabled={songExists}
                    className={`w-full flex items-center space-x-3 p-3 rounded-lg text-left transition-colors ${
                      songExists
                        ? 'bg-gray-800/50 cursor-not-allowed opacity-50'
                        : 'bg-gray-800 hover:bg-gray-700'
                    }`}
                  >
                    <img
                      src={playlist.coverUrl}
                      alt={playlist.name}
                      className="w-10 h-10 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="text-white font-medium">{playlist.name}</h3>
                      <p className="text-gray-400 text-sm">{playlist.songs.length} songs</p>
                    </div>
                    {songExists && (
                      <span className="text-green-400 text-sm">Added</span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}