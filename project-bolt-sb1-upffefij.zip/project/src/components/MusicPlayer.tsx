import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Heart } from 'lucide-react';
import { Song } from '../types';

interface MusicPlayerProps {
  currentSong: Song | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
}

export function MusicPlayer({ 
  currentSong, 
  isPlaying, 
  onPlayPause, 
  onNext, 
  onPrevious 
}: MusicPlayerProps) {
  if (!currentSong) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900/95 backdrop-blur-sm border-t border-gray-800 p-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4 flex-1">
          <img
            src={currentSong.coverUrl}
            alt={currentSong.title}
            className="w-14 h-14 rounded-lg object-cover"
          />
          <div className="min-w-0">
            <h3 className="text-white font-medium truncate">{currentSong.title}</h3>
            <p className="text-gray-400 text-sm truncate">{currentSong.artist}</p>
          </div>
          <button className="p-2 hover:bg-gray-800 rounded-full transition-colors">
            <Heart className="h-4 w-4 text-gray-400 hover:text-red-400" />
          </button>
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={onPrevious}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <SkipBack className="h-5 w-5 text-gray-300" />
          </button>
          <button
            onClick={onPlayPause}
            className="p-3 bg-purple-600 hover:bg-purple-700 rounded-full transition-colors"
          >
            {isPlaying ? (
              <Pause className="h-5 w-5 text-white" />
            ) : (
              <Play className="h-5 w-5 text-white fill-current" />
            )}
          </button>
          <button
            onClick={onNext}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <SkipForward className="h-5 w-5 text-gray-300" />
          </button>
        </div>

        <div className="flex items-center space-x-4 flex-1 justify-end">
          <div className="flex items-center space-x-2">
            <Volume2 className="h-4 w-4 text-gray-400" />
            <div className="w-20 h-1 bg-gray-700 rounded-full">
              <div className="w-3/5 h-full bg-purple-500 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}