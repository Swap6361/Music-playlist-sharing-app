import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { PlaylistCard } from './components/PlaylistCard';
import { SongCard } from './components/SongCard';
import { MusicPlayer } from './components/MusicPlayer';
import { CreatePlaylistModal } from './components/CreatePlaylistModal';
import { AddToPlaylistModal } from './components/AddToPlaylistModal';
import { ShareModal } from './components/ShareModal';
import { usePlaylist } from './hooks/usePlaylist';
import { mockSongs } from './data/mockData';
import { Song, Playlist } from './types';
import { Plus, Music } from 'lucide-react';

function App() {
  const {
    playlists,
    createPlaylist,
    addSongToPlaylist,
    getPlaylistByShareCode
  } = usePlaylist();

  const [currentView, setCurrentView] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPlaylist, setCurrentPlaylist] = useState<Song[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Modal states
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isAddToPlaylistModalOpen, setIsAddToPlaylistModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [selectedSong, setSelectedSong] = useState<Song | null>(null);
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null);

  const filteredSongs = mockSongs.filter(song =>
    song.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    song.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
    song.album.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handlePlaySong = useCallback((song: Song) => {
    setCurrentSong(song);
    setIsPlaying(true);
    setCurrentPlaylist([song]);
    setCurrentIndex(0);
  }, []);

  const handlePlayPlaylist = useCallback((playlist: Playlist) => {
    if (playlist.songs.length > 0) {
      setCurrentSong(playlist.songs[0]);
      setCurrentPlaylist(playlist.songs);
      setCurrentIndex(0);
      setIsPlaying(true);
    }
  }, []);

  const handlePlayPause = useCallback(() => {
    setIsPlaying(prev => !prev);
  }, []);

  const handleNext = useCallback(() => {
    if (currentPlaylist.length > 0) {
      const nextIndex = (currentIndex + 1) % currentPlaylist.length;
      setCurrentIndex(nextIndex);
      setCurrentSong(currentPlaylist[nextIndex]);
    }
  }, [currentIndex, currentPlaylist]);

  const handlePrevious = useCallback(() => {
    if (currentPlaylist.length > 0) {
      const prevIndex = currentIndex === 0 ? currentPlaylist.length - 1 : currentIndex - 1;
      setCurrentIndex(prevIndex);
      setCurrentSong(currentPlaylist[prevIndex]);
    }
  }, [currentIndex, currentPlaylist]);

  const handleAddToPlaylist = useCallback((song: Song) => {
    setSelectedSong(song);
    setIsAddToPlaylistModalOpen(true);
  }, []);

  const handleCreatePlaylist = useCallback((name: string, description: string, isPublic: boolean) => {
    createPlaylist(name, description);
    setIsCreateModalOpen(false);
  }, [createPlaylist]);

  const handleAddSongToPlaylist = useCallback((playlistId: string, song: Song) => {
    addSongToPlaylist(playlistId, song);
    setIsAddToPlaylistModalOpen(false);
  }, [addSongToPlaylist]);

  const handleSharePlaylist = useCallback((playlist: Playlist) => {
    setSelectedPlaylist(playlist);
    setIsShareModalOpen(true);
  }, []);

  const renderDashboard = () => (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">My Playlists</h2>
          <p className="text-gray-400 mt-1">Create and manage your personal music collections</p>
        </div>
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-lg transition-all"
        >
          <Plus className="h-4 w-4" />
          <span>Create Playlist</span>
        </button>
      </div>

      {playlists.length === 0 ? (
        <div className="text-center py-16">
          <div className="p-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Music className="h-8 w-8 text-white" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No playlists yet</h3>
          <p className="text-gray-400 mb-6 max-w-md mx-auto">
            Start building your music collection by creating your first playlist
          </p>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-lg transition-all"
          >
            Create Your First Playlist
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {playlists.map((playlist) => (
            <PlaylistCard
              key={playlist.id}
              playlist={playlist}
              onPlay={handlePlayPlaylist}
              onShare={handleSharePlaylist}
              onEdit={() => {}}
            />
          ))}
        </div>
      )}
    </div>
  );

  const renderBrowse = () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-white">Browse Songs</h2>
        <p className="text-gray-400 mt-1">Discover new music and add to your playlists</p>
      </div>

      <div className="space-y-4">
        {filteredSongs.map((song) => (
          <SongCard
            key={song.id}
            song={song}
            onPlay={handlePlaySong}
            onAddToPlaylist={handleAddToPlaylist}
          />
        ))}
      </div>

      {filteredSongs.length === 0 && searchQuery && (
        <div className="text-center py-16">
          <Music className="h-16 w-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No songs found</h3>
          <p className="text-gray-400">
            Try searching with different keywords
          </p>
        </div>
      )}
    </div>
  );

  const renderShared = () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-white">Shared Playlists</h2>
        <p className="text-gray-400 mt-1">Discover playlists shared by the community</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {playlists
          .filter(playlist => playlist.isPublic)
          .map((playlist) => (
            <PlaylistCard
              key={playlist.id}
              playlist={playlist}
              onPlay={handlePlayPlaylist}
              onShare={handleSharePlaylist}
              onEdit={() => {}}
            />
          ))}
      </div>

      {playlists.filter(playlist => playlist.isPublic).length === 0 && (
        <div className="text-center py-16">
          <Music className="h-16 w-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No shared playlists</h3>
          <p className="text-gray-400">
            Public playlists will appear here when available
          </p>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-purple-900/20">
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-32">
        {currentView === 'dashboard' && renderDashboard()}
        {currentView === 'browse' && renderBrowse()}
        {currentView === 'shared' && renderShared()}
      </main>

      <MusicPlayer
        currentSong={currentSong}
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onNext={handleNext}
        onPrevious={handlePrevious}
      />

      <CreatePlaylistModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onCreate={handleCreatePlaylist}
      />

      <AddToPlaylistModal
        isOpen={isAddToPlaylistModalOpen}
        onClose={() => setIsAddToPlaylistModalOpen(false)}
        song={selectedSong}
        playlists={playlists}
        onAddToPlaylist={handleAddSongToPlaylist}
      />

      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        playlist={selectedPlaylist}
      />
    </div>
  );
}

export default App;