export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  coverUrl: string;
  previewUrl?: string;
  genre: string;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverUrl: string;
  songs: Song[];
  createdBy: string;
  createdAt: Date;
  isPublic: boolean;
  shareCode?: string;
  collaborators: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  playlists: string[];
}